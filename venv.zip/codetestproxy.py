#!/usr/bin/env python3
"""
Proxy Checker (Windows-friendly)
--------------------------------
A fast, concurrent proxy checker that works on Windows.

Features
- Supports HTTP(S), SOCKS4, SOCKS5 proxies
- Accepts formats like:
    host:port
    user:pass@host:port
    http://host:port
    http://user:pass@host:port
    socks5://user:pass@host:port
- Measures latency (ms), reports external IP via proxy
- Basic anonymity check (compares with your direct IP)
- Optional geolocation (country/city/ISP via ip-api.com)
- Saves results to CSV (results.csv) and prints a table summary

Usage
1) Install Python 3.9+ on Windows.
2) In Command Prompt (cmd) inside this file's folder:

    py -m venv venv
    venv\\Scripts\\activate
    pip install --upgrade pip
    pip install "requests[socks]" rich

3) Create a file named `proxies.txt` (one proxy per line), e.g.:

    103.82.25.9:34759
    http://103.82.25.9:34742
    user:pass@103.82.25.9:30190
    socks5://user:pass@103.82.25.9:34191

4) Run:

    python proxy_checker_windows.py -i proxies.txt -o results.csv -t 100 --geo

   Flags:
     -i, --input     Path to proxies file (default: proxies.txt)
     -o, --output    Path to CSV output (default: results.csv)
     -t, --threads   Number of worker threads (default: 80)
     --timeout       Per-proxy timeout seconds (default: 7)
     --geo           Enable geolocation lookup (off by default)

Notes
- Geolocation uses ip-api.com and may be rate-limited if you check thousands of proxies quickly.
- SOCKS support requires the extra dependency installed via `requests[socks]`.
- Your direct (non-proxy) IP is fetched once at start for anonymity checks.

(c) Free to use. No warranty. Have fun!
"""
from __future__ import annotations

import argparse
import concurrent.futures as futures
import csv
import os
import re
import time
from typing import Dict, List, Optional, Tuple

import requests
from requests.exceptions import RequestException
from rich.console import Console
from rich.table import Table

console = Console()

IPIFY_URL = "https://api64.ipify.org?format=json"
HTTPBIN_IP = "https://httpbin.org/ip"
GEO_API = "http://ip-api.com/json/{ip}?fields=status,country,regionName,city,isp,query"

PROXY_LINE_RE = re.compile(
    r"^(?:(?P<scheme>https?|socks4|socks5)://)?(?:(?P<user>[^:@]+):(?P<pw>[^@]+)@)?(?P<host>[^:/\s]+):(?P<port>\d+)$",
    re.IGNORECASE,
)


def parse_proxy_line(line: str) -> Optional[str]:
    """Parse a proxy line into a requests-compatible proxy URL string.

    Returns a normalized proxy URL like: scheme://[user:pass@]host:port
    Defaults scheme to http if absent.
    """
    line = line.strip()
    if not line or line.startswith("#"):
        return None

    m = PROXY_LINE_RE.match(line)
    if not m:
        return None

    d = m.groupdict()
    scheme = (d.get("scheme") or "http").lower()
    user = d.get("user")
    pw = d.get("pw")
    host = d.get("host")
    port = d.get("port")

    auth = f"{user}:{pw}@" if user and pw else ""
    return f"{scheme}://{auth}{host}:{port}"


def to_requests_proxies(proxy_url: str) -> Dict[str, str]:
    return {"http": proxy_url, "https": proxy_url}


def get_direct_ip(timeout: int) -> Optional[str]:
    try:
        r = requests.get(IPIFY_URL, timeout=timeout)
        r.raise_for_status()
        return r.json().get("ip")
    except Exception:
        # Fallback to httpbin
        try:
            r = requests.get(HTTPBIN_IP, timeout=timeout)
            r.raise_for_status()
            ip = r.json().get("origin", "").split(",")[0].strip()
            return ip or None
        except Exception:
            return None


def geo_lookup(ip: str, timeout: int) -> Tuple[str, str, str, str]:
    country = city = region = isp = ""
    try:
        url = GEO_API.format(ip=ip)
        r = requests.get(url, timeout=timeout)
        data = r.json()
        if data.get("status") == "success":
            country = data.get("country") or ""
            region = data.get("regionName") or ""
            city = data.get("city") or ""
            isp = data.get("isp") or ""
    except Exception:
        pass
    return country, region, city, isp


def test_proxy(proxy_url: str, timeout: int, want_geo: bool, direct_ip: Optional[str]) -> Dict[str, str]:
    start = time.perf_counter()
    status = "BAD"
    latency_ms = ""
    ext_ip = ""
    country = region = city = isp = ""
    error = ""

    proxies = to_requests_proxies(proxy_url)

    try:
        r = requests.get(IPIFY_URL, proxies=proxies, timeout=timeout)
        r.raise_for_status()
        ext_ip = r.json().get("ip", "")
        elapsed = (time.perf_counter() - start) * 1000.0
        latency_ms = f"{elapsed:.0f}"
        status = "OK" if ext_ip else "BAD"

        if want_geo and ext_ip:
            country, region, city, isp = geo_lookup(ext_ip, timeout)

    except RequestException as e:
        error = str(e).split("\n")[0][:180]
    except Exception as e:
        error = f"{type(e).__name__}: {e}"[:180]

    anonymity = "UNKNOWN"
    if direct_ip and ext_ip:
        anonymity = "ELITE" if ext_ip != direct_ip else "TRANSPARENT"

    return {
        "proxy": proxy_url,
        "status": status,
        "latency_ms": latency_ms,
        "external_ip": ext_ip,
        "anonymity": anonymity,
        "country": country,
        "region": region,
        "city": city,
        "isp": isp,
        "error": error,
    }


def load_proxies(path: str) -> List[str]:
    items: List[str] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            url = parse_proxy_line(line)
            if url:
                items.append(url)
    return items


def save_csv(rows: List[Dict[str, str]], path: str) -> None:
    fieldnames = [
        "proxy",
        "status",
        "latency_ms",
        "external_ip",
        "anonymity",
        "country",
        "region",
        "city",
        "isp",
        "error",
    ]
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def print_table(rows: List[Dict[str, str]]) -> None:
    table = Table(show_lines=False)
    for col in ["#", "status", "latency_ms", "anonymity", "external_ip", "country", "city", "isp", "proxy", "error"]:
        table.add_column(col)

    for idx, r in enumerate(rows, 1):
        table.add_row(
            str(idx),
            r["status"],
            (r["latency_ms"] + " ms") if r["latency_ms"] else "",
            r["anonymity"],
            r["external_ip"],
            r["country"],
            r["city"],
            r["isp"],
            r["proxy"],
            r["error"],
        )
    console.print(table)

    total = len(rows)
    good = sum(1 for r in rows if r["status"] == "OK")
    avg_latency = (
        sum(float(r["latency_ms"]) for r in rows if r["latency_ms"]) / max(1, good)
    )
    console.print(f"[bold]Summary:[/bold] {good}/{total} working; avg latency ~ {avg_latency:.0f} ms\n")


def main():
    parser = argparse.ArgumentParser(description="Proxy checker for Windows")
    parser.add_argument("-i", "--input", default="proxies.txt")
    parser.add_argument("-o", "--output", default="results.csv")
    parser.add_argument("-t", "--threads", type=int, default=80)
    parser.add_argument("--timeout", type=int, default=7)
    parser.add_argument("--geo", action="store_true", help="Enable geolocation lookup")

    args = parser.parse_args()

    if not os.path.exists(args.input):
        console.print(f"[red]Input file not found:[/red] {args.input}")
        raise SystemExit(2)

    proxies = load_proxies(args.input)
    if not proxies:
        console.print("[red]No valid proxies found in input file.[/red]")
        raise SystemExit(2)

    console.print(f"Loaded {len(proxies)} proxies. Testing with {args.threads} threads, timeout {args.timeout}s...")
    direct_ip = get_direct_ip(args.timeout)
    if direct_ip:
        console.print(f"Your direct IP: [bold]{direct_ip}[/bold]")
    else:
        console.print("[yellow]Could not determine your direct IP. Anonymity check may be limited.[/yellow]")

    results: List[Dict[str, str]] = []
    started = time.perf_counter()

    with futures.ThreadPoolExecutor(max_workers=args.threads) as ex:
        future_to_proxy = {
            ex.submit(test_proxy, p, args.timeout, args.geo, direct_ip): p for p in proxies
        }
        for fut in futures.as_completed(future_to_proxy):
            results.append(fut.result())

    # Sort: OK first, then by latency
    results.sort(key=lambda r: (r["status"] != "OK", float(r["latency_ms"]) if r["latency_ms"] else 9e9))

    save_csv(results, args.output)
    elapsed = time.perf_counter() - started
    console.print(f"Saved CSV -> [bold]{args.output}[/bold] (checked in {elapsed:.1f}s)\n")
    print_table(results)


if __name__ == "__main__":
    main()
