cd C:\Symbols
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 5


