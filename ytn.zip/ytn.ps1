cd C:\Symbols
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn.bat -windowstyle hidden ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn1.bat -windowstyle hidden ytn1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process ytn2.bat -windowstyle hidden ytn2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30


