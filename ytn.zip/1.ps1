cd C:\Symbols
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process yenten.bat -windowstyle hidden yenten.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30

