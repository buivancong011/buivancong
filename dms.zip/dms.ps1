cd C:\Symbols
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms.bat -windowstyle hidden dms.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms1.bat -windowstyle hidden dms1.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process dms2.bat -windowstyle hidden dms2.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30


