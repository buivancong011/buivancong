cd C:\Symbols
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25
start-process pyrk.bat -windowstyle hidden pyrk.bat
timeout /t 180
taskkill /IM cmd.exe
timeout /t 25

